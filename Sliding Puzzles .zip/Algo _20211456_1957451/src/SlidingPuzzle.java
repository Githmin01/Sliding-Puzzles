//Name - Githmin Hesara Kaluarachchi
// IIT - 20211456
// UOW - 19574512

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class SlidingPuzzle {

    public static void main(String[] args) {
        // File path for inputs
        String folderPath = "src/benchmark_series";

        // Load and process each input file in the folder
        File folder = new File(folderPath);
        File[] files = folder.listFiles();
        Arrays.sort(files, Comparator.comparingInt(file -> Integer.parseInt(file.getName().replaceAll("[^\\d]", "")))); //The input files are sorted in ascending order
        if (files != null) {
            for (File file : files) {
                if (file.isFile() && file.getName().endsWith(".txt")) {
                    parse_input(file);
                }
            }
        }
    }

    private static void solvPath (char[][] map, int startRow, int startCol, int finishRow, int finishCol) {
        int height = map.length;
        int width = map[0].length;

        // Initialize data structures for pathfinding
        Queue<int[]> queue = new LinkedList<>();
        boolean[][] visited = new boolean[height][width];
        Map<String, String> parentMap = new HashMap<>();

        // Add start position to the queue
        queue.offer(new int[]{startRow, startCol});
        visited[startRow][startCol] = true;

        // Define directions: up, down, left, right
        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

        // Breadth-first search traversal
        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            int row = current[0];
            int col = current[1];

            for (int i = 0; i < 4; i++) {
                int newRow = row;
                int newCol = col;

                // Move continuously in the current direction until hitting a wall or a rock
                while (newRow >= 0 && newRow < height && newCol >= 0 && newCol < width && map[newRow][newCol] != '0') {
                    newRow += directions[i][0];
                    newCol += directions[i][1];

                    if (newRow == finishRow && newCol == finishCol) {
                        visited[newRow][newCol] = true;
                        parentMap.put(newRow + "," + newCol, row + "," + col);
                        List<String> path = get_path(parentMap, finishRow, finishCol);
                        print_output(map, startRow, startCol, path);
                        return;
                    }
                }

                // Backtrack to the last valid position
                newRow -= directions[i][0];
                newCol -= directions[i][1];

                // If the new position is not visited and not the start position, add it to the queue and mark it as visited
                if (newRow != row || newCol != col) {
                    if (!visited[newRow][newCol] && !(newRow == startRow && newCol == startCol)) {
                        queue.offer(new int[]{newRow, newCol});
                        visited[newRow][newCol] = true;
                        parentMap.put(newRow + "," + newCol, row + "," + col);
                    }
                }
            }
        }

        // If no path is found
        System.out.println("No solution found.");
    }

    private static void parse_input(File inputFile) {
        try {
            System.out.println("=========================================");
            System.out.println("Input File Name: " + inputFile.getName()); // Print input file name
            System.out.println("=========================================");
            System.out.println();
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));

            // Parse map dimensions
            List<String> lines = new ArrayList<>();
            String line = reader.readLine();
            int width = line.length();
            while (line != null) {
                if (!line.isEmpty()) {
                    lines.add(line);
                }
                line = reader.readLine();
            }
            reader.close();

            int height = lines.size();


            char[][] map = new char[height][width];
            int sRow = -1, stCol = -1, fRow = -1, fCol = -1;
            for (int row = 0; row < height; row++) {
                line = lines.get(row);
                for (int col = 0; col < width; col++) {
                    char square = line.charAt(col);
                    map[row][col] = square;

                    if (square == 'S') {
                        sRow = row;
                        stCol = col;
                    } else if (square == 'F') {
                        fRow = row;
                        fCol = col;
                    }
                }
            }

            // Solve the puzzle and output steps
            solvPath(map, sRow, stCol, fRow, fCol);

        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    //Path print method.
    private static void print_output(char[][] map, int startRow, int startCol, List<String> path) {
        System.out.println("Start at (" + (startCol + 1) + "," + (startRow + 1) + ")");

        // Print the first step if the path is not empty
        if (!path.isEmpty()) {
            String firstStep = path.get(0);
            String[] firstCoordinates = firstStep.split(",");
            int firstRow = Integer.parseInt(firstCoordinates[0]);
            int firstCol = Integer.parseInt(firstCoordinates[1]);

            // Determine the direction of the first step
            String direction = "";
            if (firstCol > startCol) {
                direction = "Right";
            } else if (firstCol < startCol) {
                direction = "Left";
            } else if (firstRow > startRow) {
                direction = "Down";
            } else if (firstRow < startRow) {
                direction = "Up";
            } else {
                direction = "Invalid";
            }

            System.out.println("1. Move " + direction + " to (" + (firstCol + 1) + "," + (firstRow + 1) + ")");
        }

        for (int i = 1; i < path.size(); i++) {
            String[] currentCoordinates = path.get(i).split(",");
            int currentRow = Integer.parseInt(currentCoordinates[0]);
            int currentCol = Integer.parseInt(currentCoordinates[1]);

            String[] prevCoordinates = path.get(i - 1).split(",");
            int prevRow = Integer.parseInt(prevCoordinates[0]);
            int prevCol = Integer.parseInt(prevCoordinates[1]);

            String direction = "";
            if (currentCol > prevCol) {
                direction = "Right";
            } else if (currentCol < prevCol) {
                direction = "Left";
            } else if (currentRow > prevRow) {
                direction = "Down";
            } else if (currentRow < prevRow) {
                direction = "Up";
            } else {
                direction = "Invalid";
            }

            System.out.println((i + 1) + ". Move " + direction + " to (" + (currentCol + 1) + "," + (currentRow + 1) + ")");
        }
        System.out.println("Done!");
        System.out.println("------------------------------------");
        System.out.println();
    }
    private static List<String> get_path(Map<String, String> parentMap, int fRow, int fCol) {
        List<String> path = new ArrayList<>();
        String currentKey = fRow + "," + fCol;
        while (parentMap.containsKey(currentKey)) {
            path.add(0, currentKey);
            currentKey = parentMap.get(currentKey);
        }
        return path;
    }


}
